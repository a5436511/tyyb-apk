翼支付湖南电信权益助手 - Android 工程
========================================

技术栈：原生 Android (Java) + HttpURLConnection
无需任何第三方网络库，纯系统 API。

=== 如何编译出 APK ===

方式一（推荐，电脑上）：
1. 电脑安装 Android Studio（官网下载）
2. File -> Open，选择 yzf_app 文件夹
3. 等待 Gradle 同步完成
4. 插上手机开 USB 调试，点 Run；或 Build -> Build APK(s)
5. APK 输出位置：app/build/outputs/apk/debug/app-debug.apk

方式二（命令行）：
   cd yzf_app
   gradlew assembleDebug        (Windows 用 gradlew.bat)

=== 使用步骤 ===
1. 手机浏览器打开 https://yzf.hn.189.cn/rights/c/DetailsYzf 并登录
2. 浏览器 F12/开发者工具 控制台输入 document.cookie 回车
3. 复制输出的一整串内容
4. 打开本 App，粘贴到 Cookie 输入框
5. 点「查询权益」先看响应，再点「自动兑换」

=== 重要说明 ===
- 详情接口响应结构未在本环境抓到完整样本，App 内置了通用递归解析，
  首次「查询权益」后请根据日志里的 JSON 字段反馈迭代兑换参数映射。
- 兑换请求参数名（rightsId/resourceId/rightsType）如与实际不符，
  需要微调 MainActivity.java 里 buildExchangeBody 对应字段。
- 仅用于技术学习、个人账号自助操作演示，使用风险自负。
