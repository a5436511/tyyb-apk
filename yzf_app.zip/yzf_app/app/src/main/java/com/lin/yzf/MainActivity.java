package com.lin.yzf;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 翼支付湖南电信权益助手
 * 功能：输入 Cookie -> 查询可领权益 -> 自动兑换
 * 仅用于技术学习、个人账号自助操作，使用风险自负。
 */
public class MainActivity extends Activity {

    private static final String BASE = "https://yzf.hn.189.cn";
    private static final String DETAIL_URL =
            BASE + "/rightsAppService/c/queryRights/qryRightsDetailsForTY";
    private static final String EXCHANGE_URL =
            BASE + "/rightsAppService/c/rightsObtain/creditsExchange";

    private EditText ckInput;
    private TextView logView;
    private Button queryBtn;
    private Button autoBtn;
    private Button clearBtn;

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(16);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("翼支付权益助手");
        title.setTextSize(20);
        root.addView(title);

        TextView ckLabel = new TextView(this);
        ckLabel.setText("\nCookie（登录后浏览器 F12 控制台输入 document.cookie 复制）:");
        root.addView(ckLabel);

        ckInput = new EditText(this);
        ckInput.setHint("粘贴完整 Cookie");
        ckInput.setMinLines(3);
        ckInput.setMaxLines(6);
        root.addView(ckInput);

        LinearLayout btnRow = new LinearLayout(this);
        btnRow.setOrientation(LinearLayout.HORIZONTAL);

        queryBtn = new Button(this);
        queryBtn.setText("查询权益");
        queryBtn.setOnClickListener(v -> doQuery());
        btnRow.addView(queryBtn);

        autoBtn = new Button(this);
        autoBtn.setText("自动兑换");
        autoBtn.setOnClickListener(v -> doAuto());
        btnRow.addView(autoBtn);

        clearBtn = new Button(this);
        clearBtn.setText("清空日志");
        clearBtn.setOnClickListener(v -> logView.setText(""));
        btnRow.addView(clearBtn);

        root.addView(btnRow);

        logView = new TextView(this);
        logView.setTextSize(12);
        logView.setPadding(0, dp(12), 0, 0);
        root.addView(logView);

        scroll.addView(root);
        setContentView(scroll);
    }

    private String getCookie() {
        String ck = ckInput.getText().toString().trim();
        if (ck.toLowerCase().startsWith("ck=")) {
            ck = ck.substring(3);
        }
        return ck;
    }

    private void doQuery() {
        String ck = getCookie();
        if (TextUtils.isEmpty(ck)) {
            toast("请先粘贴 Cookie");
            return;
        }
        setBusy(true);
        executor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("rightsType", "1");
                body.put("systemVersion", "");
                body.put("channelId", "5");
                String resp = postJson(DETAIL_URL, body.toString(), ck);
                String pretty = prettyJson(resp);
                mainHandler.post(() -> {
                    log("========== 详情接口响应 ==========\n" + pretty + "\n========== 响应结束 ==========");
                    setBusy(false);
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    log("查询失败: " + e.getMessage());
                    setBusy(false);
                });
            }
        });
    }

    private void doAuto() {
        String ck = getCookie();
        if (TextUtils.isEmpty(ck)) {
            toast("请先粘贴 Cookie");
            return;
        }
        setBusy(true);
        executor.execute(() -> {
            try {
                JSONObject body = new JSONObject();
                body.put("rightsType", "1");
                body.put("systemVersion", "");
                body.put("channelId", "5");
                String resp = postJson(DETAIL_URL, body.toString(), ck);
                mainHandler.post(() -> log("详情接口原始响应:\n" + prettyJson(resp)));

                JSONObject root = new JSONObject(resp);
                List<JSONObject> items = findRightsItems(root);
                List<JSONObject> exchangeable = new ArrayList<>();
                for (JSONObject it : items) {
                    if (isExchangeable(it)) {
                        exchangeable.add(it);
                    }
                }
                int n = exchangeable.size();
                mainHandler.post(() -> log("通用解析发现 " + items.size() + " 个条目，可兑换 " + n + " 个"));

                String customerId = extractCustomerId(ck);
                if (TextUtils.isEmpty(customerId)) {
                    mainHandler.post(() -> {
                        log("未能从 Cookie 自动识别手机号，请确认 Cookie 或稍后手动填参");
                        setBusy(false);
                    });
                    return;
                }
                mainHandler.post(() -> log("使用 customerId: " + customerId));

                int ok = 0;
                for (int i = 0; i < exchangeable.size(); i++) {
                    JSONObject it = exchangeable.get(i);
                    JSONObject ex = new JSONObject();
                    ex.put("customerId", customerId);
                    ex.put("rightsId", first(it, "rightsId", "giftRightsId", "giftId"));
                    ex.put("rightsType", first(it, "rightsType", "type"));
                    ex.put("resourceId", first(it, "resourceId"));
                    ex.put("rightsResourceId", first(it, "rightsResourceId", "rightsResId"));
                    ex.put("receiveTime", new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.CHINA).format(new Date()));
                    ex.put("channelId", "5");
                    String exResp = postJson(EXCHANGE_URL, ex.toString(), ck);
                    final int idx = i + 1;
                    final String exLog = exResp;
                    mainHandler.post(() -> log("兑换 " + idx + "/" + exchangeable.size() + " 响应:\n" + prettyJson(exLog)));
                    ok++;
                    Thread.sleep(3000);
                }
                final int finalOk = ok;
                mainHandler.post(() -> {
                    log("本次尝试兑换 " + exchangeable.size() + " 项，已发送 " + finalOk + " 项");
                    setBusy(false);
                });
            } catch (Exception e) {
                mainHandler.post(() -> {
                    log("自动兑换失败: " + e.getMessage());
                    setBusy(false);
                });
            }
        });
    }

    private List<JSONObject> findRightsItems(Object obj) {
        List<JSONObject> out = new ArrayList<>();
        collectRights(obj, out, 0);
        return out;
    }

    private void collectRights(Object obj, List<JSONObject> out, int depth) {
        if (obj == null || depth > 8) return;
        if (obj instanceof JSONObject) {
            JSONObject o = (JSONObject) obj;
            if (o.has("rightsId") || o.has("resourceId") || o.has("giftRightsId")
                    || o.has("rightsResourceId") || o.has("rightsName")) {
                out.add(o);
            }
            JSONArray names = o.names();
            if (names != null) {
                for (int i = 0; i < names.length(); i++) {
                    collectRights(o.opt(names.optString(i)), out, depth + 1);
                }
            }
        } else if (obj instanceof JSONArray) {
            JSONArray a = (JSONArray) obj;
            for (int i = 0; i < a.length(); i++) {
                collectRights(a.opt(i), out, depth + 1);
            }
        }
    }

    private boolean isExchangeable(JSONObject it) {
        String text = it.toString();
        if (text.contains("立即兑换") || text.contains("立即领取") || text.contains("去兑换")) {
            return true;
        }
        if (text.contains("已领完") || text.contains("已领取") || text.contains("已兑换")
                || text.contains("兑换完")) {
            return false;
        }
        Object st = first(it, "status", "rightsStatus", "receiveStatus", "btnFlag",
                "state", "exchangeFlag");
        if (st != null) {
            String s = String.valueOf(st);
            return !("0".equals(s) || "".equals(s) || "null".equals(s)
                    || "false".equals(s) || "2".equals(s) || "3".equals(s));
        }
        return false;
    }

    private Object first(JSONObject o, String... keys) {
        for (String k : keys) {
            if (o.has(k) && !o.isNull(k)) return o.opt(k);
        }
        return null;
    }

    private String extractCustomerId(String ck) {
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(?:phone|mobile|loginId|account)=([0-9]{11})")
                .matcher(ck);
        return m.find() ? m.group(1) : "";
    }

    private String postJson(String urlStr, String json, String cookie) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(15000);
        conn.setDoOutput(true);
        conn.setRequestProperty("Content-Type", "application/json");
        conn.setRequestProperty("Accept", "application/json, text/plain, */*");
        conn.setRequestProperty("User-Agent",
                "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 " +
                        "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36");
        conn.setRequestProperty("Referer", BASE + "/rights/c/DetailsYzf");
        conn.setRequestProperty("Cookie", cookie);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(json.getBytes(StandardCharsets.UTF_8));
        }

        int code = conn.getResponseCode();
        java.io.InputStream is = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
        if (is == null) is = conn.getInputStream();
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line);
        }
        return sb.toString();
    }

    private String prettyJson(String raw) {
        try {
            Object o = raw.trim().startsWith("{")
                    ? new JSONObject(raw)
                    : (raw.trim().startsWith("[") ? new JSONArray(raw) : raw);
            return o instanceof JSONObject ? ((JSONObject) o).toString(2)
                    : o instanceof JSONArray ? ((JSONArray) o).toString(2) : raw;
        } catch (Exception e) {
            return raw;
        }
    }

    private void log(String msg) {
        logView.append(msg + "\n");
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private void setBusy(boolean busy) {
        queryBtn.setEnabled(!busy);
        autoBtn.setEnabled(!busy);
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
